import React from 'react'
import CartContainer from './MfeContainer'
export default function App() {
  return (
    <>
        <div>This is the container</div>
        <CartContainer />
    </>
  )
}
