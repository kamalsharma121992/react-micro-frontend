# react-micro-frontend
React micro frontend using ModuleFederationPlugin
